/* ===========================================================
   AIMOCK — app.js
   Client-side "backend": all state lives in localStorage.
   (See README.md for how to swap this for a real server.)
=========================================================== */
(function(){
"use strict";

/* ---------------- tiny helpers ---------------- */
const $  = (s,r=document)=>r.querySelector(s);
const $$ = (s,r=document)=>[...r.querySelectorAll(s)];
const store = {
  get(k,fallback){ try{ const v = localStorage.getItem(k); return v?JSON.parse(v):fallback; }catch(e){ return fallback; } },
  set(k,v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(e){} }
};
function toast(msg, kind=""){
  const host = $('#toastHost');
  const el = document.createElement('div');
  el.className = 'toast ' + kind;
  el.textContent = msg;
  host.appendChild(el);
  setTimeout(()=>{ el.style.opacity='0'; el.style.transition='opacity .3s'; setTimeout(()=>el.remove(),300); }, 4200);
}
function fmtTime(sec){
  const m = Math.floor(sec/60).toString().padStart(2,'0');
  const s = Math.floor(sec%60).toString().padStart(2,'0');
  return `${m}:${s}`;
}
function scoreClass(n){ return n>=75?'score-hi': n>=50?'score-mid':'score-lo'; }

/* ---------------- scroll reveal ---------------- */
const io = new IntersectionObserver((entries)=>{
  entries.forEach(e=>{ if(e.isIntersecting){ e.target.classList.add('in'); io.unobserve(e.target);} });
},{threshold:.12});
$$('.reveal').forEach(el=>io.observe(el));

/* ---------------- hero ambient wave (decorative, always animates) ---------------- */
// purely CSS-driven, nothing to init here.

/* ===========================================================
   AUTH
=========================================================== */
const authOverlay = $('#authOverlay');
let pendingUser = {};
let currentOtp = null;

function openAuth(){ authOverlay.classList.add('active'); goToStep('method'); }
function closeAuth(){ authOverlay.classList.remove('active'); }
function goToStep(name){
  $$('.auth-step').forEach(s=>s.classList.toggle('active', s.dataset.step===name));
}

$('#btnGetStartedTop').onclick = openAuth;
$('#btnGetStartedHero').onclick = openAuth;
$('#btnGetStartedFooter').onclick = openAuth;
$('#btnLoginTop').onclick = openAuth;
$('#authClose').onclick = closeAuth;
$('#btnWatchDemo').onclick = ()=> document.getElementById('features').scrollIntoView({behavior:'smooth'});

$$('.step-back').forEach(b=> b.onclick = ()=> goToStep(b.dataset.back));

// Demo "social" sign-in — no real OAuth backend is wired up here (that requires
// server-side client secrets), so this simulates a successful Google/LinkedIn
// login and drops the user straight into phone verification, same as the
// real flow would after OAuth consent.
$('#btnGoogle').onclick = ()=>{
  pendingUser = { name:'Google User', email:'you@gmail.com', provider:'Google' };
  toast('Signed in with Google (demo mode)', 'ok');
  goToStep('phone');
};
$('#btnLinkedIn').onclick = ()=>{
  pendingUser = { name:'LinkedIn User', email:'you@linkedin.com', provider:'LinkedIn' };
  toast('Signed in with LinkedIn (demo mode)', 'ok');
  goToStep('phone');
};

$('#btnContinuePhone').onclick = ()=>{
  const name = $('#inpName').value.trim();
  const email = $('#inpEmail').value.trim();
  if(!name || !email){ toast('Enter your name and email to continue', 'warn'); return; }
  if(!/^\S+@\S+\.\S+$/.test(email)){ toast('That email looks incomplete', 'warn'); return; }
  pendingUser = { name, email, provider:'Email' };
  goToStep('phone');
};

$('#btnSendOtp').onclick = ()=>{
  const code = $('#inpCountryCode').value;
  const phone = $('#inpPhone').value.trim();
  if(phone.replace(/\D/g,'').length < 7){ toast('Enter a valid phone number', 'warn'); return; }
  pendingUser.phone = code + ' ' + phone;
  currentOtp = String(Math.floor(100000 + Math.random()*900000));
  $('#otpSubText').textContent = `Sent to ${pendingUser.phone}`;
  // Honest limitation: sending a real SMS needs a paid provider (Twilio, MSG91, etc.)
  // wired to a real backend. This demo shows the code on-screen instead of texting it.
  $('#otpDemoNote').textContent = `Demo mode — no SMS gateway connected, so here's the code: ${currentOtp}`;
  goToStep('otp');
  setTimeout(()=> $('.otp-box[data-i="0"]').focus(), 250);
};
$('#btnResendOtp').onclick = ()=>{
  currentOtp = String(Math.floor(100000 + Math.random()*900000));
  $('#otpDemoNote').textContent = `New code sent (demo): ${currentOtp}`;
  toast('New code generated', 'ok');
};

// OTP box auto-advance
$$('.otp-box').forEach((box,i)=>{
  box.addEventListener('input', ()=>{
    box.value = box.value.replace(/\D/g,'');
    if(box.value && i < 5) $$('.otp-box')[i+1].focus();
  });
  box.addEventListener('keydown', (e)=>{
    if(e.key==='Backspace' && !box.value && i>0) $$('.otp-box')[i-1].focus();
  });
});

$('#btnVerifyOtp').onclick = ()=>{
  const entered = $$('.otp-box').map(b=>b.value).join('');
  if(entered.length < 6){ toast('Enter all 6 digits', 'warn'); return; }
  if(entered !== currentOtp){ toast('That code doesn\'t match — check the demo note above', 'err'); return; }
  const users = store.get('aimock_users', {});
  const id = pendingUser.email.toLowerCase();
  users[id] = { ...pendingUser, id, joined: users[id]?.joined || Date.now() };
  store.set('aimock_users', users);
  store.set('aimock_session', id);
  toast(`Welcome, ${pendingUser.name.split(' ')[0]}!`, 'ok');
  closeAuth();
  enterApp();
};

/* ===========================================================
   APP SHELL / ROUTING
=========================================================== */
function currentUser(){
  const id = store.get('aimock_session', null);
  if(!id) return null;
  const users = store.get('aimock_users', {});
  return users[id] || null;
}

function enterApp(){
  const user = currentUser();
  if(!user){ openAuth(); return; }
  $('#view-landing').classList.remove('active');
  $('#view-app').classList.add('active');
  $('#sideUserName').textContent = user.name;
  $('#userInitial').textContent = user.name.trim()[0]?.toUpperCase() || 'U';
  $('#dashGreeting').textContent = `Welcome back, ${user.name.split(' ')[0]}`;
  showPanel('dashboard');
  renderDashboard();
}

$('#btnLogout').onclick = ()=>{
  store.set('aimock_session', null);
  $('#view-app').classList.remove('active');
  $('#view-landing').classList.add('active');
  toast('Signed out');
};

function showPanel(name){
  $$('.panel').forEach(p=>p.classList.toggle('active', p.dataset.panel===name));
  $$('.side-link').forEach(l=>l.classList.toggle('active', l.dataset.panel===name));
  if(name==='dashboard') renderDashboard();
  if(name==='history') renderHistory();
}
$$('.side-link').forEach(l=> l.onclick = ()=> showPanel(l.dataset.panel));
$$('[data-goto]').forEach(b=> b.onclick = ()=> showPanel(b.dataset.goto));

/* ===========================================================
   DASHBOARD
=========================================================== */
function getHistory(){
  const user = currentUser(); if(!user) return [];
  return store.get('aimock_history_'+user.id, []);
}
function saveHistory(list){
  const user = currentUser(); if(!user) return;
  store.set('aimock_history_'+user.id, list);
}

const TIPS = [
  "Answer in the STAR shape: Situation, Task, Action, Result — it keeps you from rambling.",
  "A short pause before answering reads as composure, not weakness.",
  "Numbers stick. \"Cut load time 40%\" beats \"made it faster\" every time.",
  "Mirror 2–3 keywords from the job description in your answers — it signals fit.",
  "If you don't know something, say what you'd do to find out. That's still a real answer.",
  "Cut filler words by simply finishing your sentence, then pausing, instead of bridging with 'um'.",
];

function renderDashboard(){
  const hist = getHistory();
  $('#statCount').textContent = hist.length;
  if(hist.length){
    const scores = hist.map(h=>h.overall);
    const avg = Math.round(scores.reduce((a,b)=>a+b,0)/scores.length);
    $('#statAvg').textContent = avg;
    $('#statAvgNote').textContent = avg>=75 ? 'Strong — keep it up' : avg>=50 ? 'Solid, room to grow' : 'Focus practice pays off fast';
    $('#statBest').textContent = Math.max(...scores);
  } else {
    $('#statAvg').textContent = '–'; $('#statBest').textContent = '–';
  }
  // streak: consecutive days with a session, ending today or yesterday
  let streak = 0;
  if(hist.length){
    const days = [...new Set(hist.map(h=> new Date(h.date).toDateString()))];
    let cursor = new Date();
    while(days.includes(cursor.toDateString())){ streak++; cursor.setDate(cursor.getDate()-1); }
  }
  $('#statStreak').innerHTML = streak + '<span class="unit">days</span>';

  // tips: rotate, prefer relevant to weakest subscore of most recent
  const tips = [...TIPS].sort(()=>Math.random()-.5).slice(0,4);
  $('#tipsList').innerHTML = tips.map(t=>`<li>${t}</li>`).join('');

  // recent list
  const recent = [...hist].reverse().slice(0,5);
  $('#recentList').innerHTML = recent.length ? recent.map(h=>`
    <div class="recent-row" data-id="${h.id}">
      <div><p class="rr-role">${h.role}</p><p class="rr-date">${new Date(h.date).toLocaleDateString(undefined,{month:'short',day:'numeric',year:'numeric'})} · ${h.type}</p></div>
      <span class="rr-score ${scoreClass(h.overall)}">${h.overall}</span>
    </div>`).join('') : `<p class="empty-note">No sessions yet — start your first interview to see it here.</p>`;
  $$('.recent-row').forEach(r=> r.onclick = ()=> openReport(r.dataset.id));

  // trend chart
  drawTrend(hist.slice(-10));
}

function drawTrend(hist){
  const svg = $('#trendChart');
  const empty = $('#trendEmpty');
  if(!hist.length){ svg.innerHTML=''; empty.style.display='block'; return; }
  empty.style.display='none';
  const w=560,h=200,pad=24;
  const coords = hist.map((item,i)=>{
    const x = pad + (i*(w-2*pad))/Math.max(hist.length-1,1);
    const y = pad + (100-item.overall)/100*(h-2*pad);
    return {x, y};
  });
  const path = coords.map((c,i)=> (i===0?'M':'L')+c.x.toFixed(1)+','+c.y.toFixed(1)).join(' ');
  const area = path + ` L${coords[coords.length-1].x.toFixed(1)},${h-pad} L${coords[0].x.toFixed(1)},${h-pad} Z`;
  svg.innerHTML = `
    <defs>
      <linearGradient id="trendGrad" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="#7C5CFF" stop-opacity=".45"/>
        <stop offset="100%" stop-color="#7C5CFF" stop-opacity="0"/>
      </linearGradient>
    </defs>
    <path d="${area}" fill="url(#trendGrad)" stroke="none"></path>
    <path d="${path}" fill="none" stroke="#a78bff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"></path>
    ${coords.map((c,i)=>`<circle cx="${c.x.toFixed(1)}" cy="${c.y.toFixed(1)}" r="4" fill="#F0B94D"><title>${hist[i].overall}</title></circle>`).join('')}
  `;
}

/* ===========================================================
   SETUP — resume / JD intake
=========================================================== */
let resumeText = '', jdText = '';

function wireDropzone(zoneId, inputId, statusId, onText){
  const zone = $('#'+zoneId), input = $('#'+inputId), status = $('#'+statusId);
  zone.onclick = ()=> input.click();
  ['dragover','dragleave','drop'].forEach(evt=>{
    zone.addEventListener(evt, e=>{
      e.preventDefault();
      zone.classList.toggle('drag', evt==='dragover');
    });
  });
  zone.addEventListener('drop', e=>{
    const f = e.dataTransfer.files[0];
    if(f) handleFile(f);
  });
  input.addEventListener('change', ()=>{ if(input.files[0]) handleFile(input.files[0]); });

  async function handleFile(file){
    status.textContent = 'Reading ' + file.name + '…';
    try{
      let text = '';
      if(file.type === 'application/pdf' || file.name.endsWith('.pdf')){
        text = await extractPdfText(file);
      } else {
        text = await file.text();
      }
      onText(text);
      status.textContent = `Loaded "${file.name}" (${text.split(/\s+/).length} words)`;
    }catch(err){
      status.textContent = '';
      toast('Couldn\'t read that file — try pasting the text instead', 'warn');
    }
  }
}

async function extractPdfText(file){
  if(!window.pdfjsLib){ throw new Error('pdf.js unavailable'); }
  pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
  const buf = await file.arrayBuffer();
  const doc = await pdfjsLib.getDocument({data: buf}).promise;
  let out = '';
  for(let i=1;i<=doc.numPages;i++){
    const page = await doc.getPage(i);
    const content = await page.getTextContent();
    out += content.items.map(it=>it.str).join(' ') + '\n';
  }
  return out;
}

wireDropzone('dropResume','fileResume','resumeStatus', t=>{ resumeText=t; $('#taResume').value=t; });
wireDropzone('dropJd','fileJd','jdStatus', t=>{ jdText=t; $('#taJd').value=t; });
$('#taResume').addEventListener('input', ()=> resumeText = $('#taResume').value);
$('#taJd').addEventListener('input', ()=> jdText = $('#taJd').value);

/* ===========================================================
   QUESTION GENERATION ENGINE
   Builds a pool of candidate questions from: role templates,
   behavioral bank, and résumé/JD keyword hits — then filters
   out anything asked in this user's last sessions so repeat
   practice stays fresh.
=========================================================== */
const SKILL_LEXICON = [
  'javascript','python','java','react','node','sql','aws','azure','docker','kubernetes',
  'figma','photoshop','excel','tableau','power bi','salesforce','seo','google ads','django',
  'machine learning','data analysis','project management','agile','scrum','typescript',
  'html','css','api','rest','graphql','git','ci/cd','testing','leadership','stakeholder',
  'budget','forecasting','copywriting','crm','negotiation','recruitment','a/b testing'
];

const BEHAVIORAL_BANK = [
  "Tell me about a time you disagreed with a teammate's approach. How did you handle it?",
  "Describe a project that didn't go as planned. What did you do next?",
  "Walk me through a time you had to learn something quickly under pressure.",
  "Tell me about a time you received tough feedback. What changed afterward?",
  "Describe a situation where you had to prioritize between two urgent tasks.",
  "Tell me about a time you made a mistake at work. How did you handle it?",
  "Describe a time you had to convince someone to see things your way.",
  "Tell me about a goal you set for yourself and how you pursued it.",
  "Describe the most difficult stakeholder or client you've worked with.",
  "Tell me about a time you took initiative without being asked.",
  "Describe how you handle working under a tight deadline.",
  "Tell me about a time you had to give someone difficult feedback.",
];

const ROLE_TEMPLATES = {
  general: [
    "Walk me through your background and why this role caught your attention.",
    "What does success look like for you in the first 90 days here?",
    "What's one thing on your résumé you're proudest of, and why?",
    "Where do you want to be in your career three years from now?",
  ],
  software: [
    "Walk me through how you'd design a system that needs to handle a sudden 10x traffic spike.",
    "Tell me about the most complex bug you've debugged. How did you track it down?",
    "How do you decide when to refactor code versus ship the feature as-is?",
    "Describe how you approach writing tests for a new feature.",
    "Explain a technical decision you made that you'd reconsider today.",
  ],
  data: [
    "Walk me through how you'd validate that a dashboard metric is actually trustworthy.",
    "Describe a time an analysis you ran changed a real business decision.",
    "How do you explain a statistically significant but practically tiny result to a non-technical stakeholder?",
    "Tell me about a time your data told a different story than everyone expected.",
  ],
  product: [
    "Walk me through how you'd prioritize a backlog with three teams each convinced their feature is P0.",
    "Tell me about a feature you shipped that didn't move the metric you expected. What did you learn?",
    "How do you decide when to say no to a stakeholder's request?",
    "Describe how you'd define success metrics for a brand-new feature.",
  ],
  design: [
    "Walk me through your process from a rough brief to a shipped design.",
    "Tell me about a time user research changed a design you were attached to.",
    "How do you defend a design decision to someone who just wants it 'simpler'?",
    "Describe how you balance accessibility with a bold visual direction.",
  ],
  marketing: [
    "Walk me through how you'd launch a campaign with a limited budget.",
    "Tell me about a campaign that underperformed. What did you change?",
    "How do you decide which channel deserves the next marketing dollar?",
    "Describe how you measure brand impact versus direct-response impact.",
  ],
  sales: [
    "Walk me through how you'd handle a prospect who's gone cold after a strong first call.",
    "Tell me about the toughest objection you've had to overcome in a pitch.",
    "How do you qualify whether a lead is actually worth your time?",
    "Describe how you rebuilt trust after losing a client's confidence.",
  ],
  support: [
    "Walk me through how you'd handle an angry customer with a legitimate complaint.",
    "Tell me about a time you had to say no to a customer request. How did you frame it?",
    "How do you decide when to escalate a ticket versus solve it yourself?",
    "Describe how you keep quality high when ticket volume spikes.",
  ],
  hr: [
    "Walk me through how you'd handle a conflict between two team members.",
    "Tell me about a hiring decision you'd make differently in hindsight.",
    "How do you balance advocating for an employee with representing the company?",
    "Describe how you'd design an onboarding flow for a hybrid team.",
  ],
  finance: [
    "Walk me through how you'd build a forecast when historical data is unreliable.",
    "Tell me about a time you caught an error in a financial model before it mattered.",
    "How do you explain a budget variance to a non-finance stakeholder?",
    "Describe a trade-off between short-term savings and long-term investment you've evaluated.",
  ],
};

function extractSkillHits(text){
  const lower = (text||'').toLowerCase();
  return SKILL_LEXICON.filter(k=> lower.includes(k));
}

function buildQuestionPool({role, type, resume, jd}){
  let pool = [];
  const skillHits = [...new Set([...extractSkillHits(resume), ...extractSkillHits(jd)])];

  if(type !== 'behavioral'){
    pool.push(...(ROLE_TEMPLATES[role] || ROLE_TEMPLATES.general));
    skillHits.slice(0,4).forEach(skill=>{
      pool.push(`I noticed ${skill} come up — walk me through the most substantial thing you've built or done with it.`);
    });
  }
  if(type !== 'technical'){
    pool.push(...BEHAVIORAL_BANK);
  }
  // JD-specific: pull a distinctive line from the JD if present
  if(jd && jd.trim().length > 40){
    const sentences = jd.split(/[.\n]/).map(s=>s.trim()).filter(s=>s.length>25 && s.length<160);
    if(sentences.length){
      const pick = sentences[Math.floor(Math.random()*sentences.length)];
      pool.push(`The role mentions: "${pick}". What's your direct experience with that?`);
    }
  }
  // Resume-specific opener
  if(resume && resume.trim().length > 40){
    pool.push("Pick the résumé line you're most excited to talk about — walk me through it.");
  }
  pool.push(...(ROLE_TEMPLATES.general));
  return [...new Set(pool)];
}

function pickQuestions(pool, count, userId){
  const usedKey = 'aimock_used_questions_' + userId;
  let used = new Set(store.get(usedKey, []));
  let fresh = pool.filter(q=>!used.has(q));
  if(fresh.length < count){ used = new Set(); fresh = pool.slice(); } // pool exhausted -> reset so practice never stalls
  fresh = fresh.sort(()=>Math.random()-.5);
  const chosen = fresh.slice(0, count);
  chosen.forEach(q=>used.add(q));
  store.set(usedKey, [...used]);
  return chosen;
}

/* ===========================================================
   INTERVIEW ROOM ENGINE
=========================================================== */
let session = null; // {questions, index, answers[], role, type, difficulty, startedAt}
let mediaStream = null;
let recognition = null;
let recognizing = false;
let paused = false;
let timerHandle = null;
let elapsedSec = 0;
let answerStartWordTimes = [];
let speechSupported = 'webkitSpeechRecognition' in window || 'SpeechRecognition' in window;

$('#btnBuildInterview').onclick = ()=>{
  const user = currentUser(); if(!user) return;
  const role = $('#selRole').value;
  const type = $('#selType').value;
  const difficulty = $('#selDifficulty').value;
  const count = parseInt($('#selCount').value,10);
  const pool = buildQuestionPool({role, type, resume:resumeText, jd:jdText});
  const questions = pickQuestions(pool, count, user.id);
  session = {
    role: roleLabel(role), type: typeLabel(type), difficulty, questions,
    index: 0, answers: [], startedAt: Date.now()
  };
  document.querySelectorAll('.panel').forEach(p=>p.classList.toggle('active', p.dataset.panel==='room'));
  $$('.side-link').forEach(l=>l.classList.remove('active'));
  $('#roomMetaRole').textContent = 'Role: ' + session.role;
  $('#roomMetaType').textContent = 'Type: ' + session.type;
  renderQList();
  startRoom();
};

function roleLabel(v){ return {general:'General',software:'Software Engineering',data:'Data / Analytics',product:'Product Management',design:'Design (UX/UI)',marketing:'Marketing',sales:'Sales / Business Dev',support:'Customer Support',hr:'HR / Recruiting',finance:'Finance'}[v]||v; }
function typeLabel(v){ return {mixed:'Mixed',behavioral:'Behavioral',technical:'Technical'}[v]||v; }

function renderQList(){
  $('#qList').innerHTML = session.questions.map((q,i)=>`
    <div class="qlist-item ${i===session.index?'current':i<session.index?'done':''}">${i+1}. ${q.length>70?q.slice(0,70)+'…':q}</div>
  `).join('');
}

async function startRoom(){
  elapsedSec = 0; paused = false;
  $('#btnPauseResume').textContent = '⏸ Pause';
  clearInterval(timerHandle);
  timerHandle = setInterval(()=>{ if(!paused){ elapsedSec++; $('#roomTimer').textContent = fmtTime(elapsedSec); } }, 1000);
  await setupCamera();
  setupRecognition();
  askCurrentQuestion();
}

async function setupCamera(){
  const camBox = $('#camBox'), video = $('#camVideo'), note = $('#camOffNote');
  if(!window.isSecureContext){
    note.textContent = 'Camera needs HTTPS or localhost — continuing audio-only';
    note.style.display='flex'; video.style.display='none';
    toast('This page isn\'t on a secure origin, so the browser blocks the camera. Serve it over https/localhost to enable video.', 'warn');
    return;
  }
  try{
    mediaStream = await navigator.mediaDevices.getUserMedia({ video:true, audio:true });
    video.srcObject = mediaStream;
    note.style.display='none'; video.style.display='block';
  }catch(err){
    note.style.display='flex'; video.style.display='none';
    note.textContent = err.name==='NotAllowedError' ? 'Camera/mic permission denied' : 'No camera detected';
    toast('Camera unavailable (' + err.name + ') — you can still continue with voice or typed answers.', 'warn');
  }
}

function setMicState(state, text){
  const dot = $('#micDot');
  dot.className = 'mic-dot' + (state?(' '+state):'');
  $('#micStatusText').textContent = text;
}

function setupRecognition(){
  if(!speechSupported){
    setMicState('warn', 'Speech recognition isn\'t supported in this browser — type your answer below instead.');
    return;
  }
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  recognition = new SR();
  recognition.continuous = true;
  recognition.interimResults = true;
  recognition.lang = 'en-US';

  let finalTranscript = '';

  recognition.onstart = ()=>{
    recognizing = true;
    setMicState('live', 'Listening…');
    $('#liveWave').classList.add('active');
  };
  recognition.onerror = (e)=>{
    if(e.error === 'no-speech'){
      setMicState('warn', 'Didn\'t catch that — keep talking, or just type your answer.');
      return; // not fatal, recognition auto-restarts via onend
    }
    if(e.error === 'not-allowed' || e.error === 'service-not-allowed'){
      setMicState('error', 'Microphone permission blocked — type your answer instead.');
      speechSupported = false;
      return;
    }
    if(e.error === 'audio-capture'){
      setMicState('error', 'No microphone found — type your answer instead.');
      speechSupported = false;
      return;
    }
    setMicState('warn', 'Mic hiccup (' + e.error + ') — retrying automatically.');
  };
  recognition.onresult = (e)=>{
    let interim = '';
    for(let i=e.resultIndex;i<e.results.length;i++){
      const t = e.results[i][0].transcript;
      if(e.results[i].isFinal) finalTranscript += t + ' ';
      else interim += t;
    }
    $('#liveTranscript').value = (finalTranscript + interim).trim();
  };
  recognition.onend = ()=>{
    recognizing = false;
    $('#liveWave').classList.remove('active');
    // auto-restart while the room is open & not paused, so short silences don't kill listening
    if(session && !paused && speechSupported && $('.panel[data-panel="room"]').classList.contains('active')){
      try{ recognition.start(); }catch(e){/* already starting */}
    } else {
      setMicState('', 'Microphone paused');
    }
  };

  try{
    recognition.start();
  }catch(err){
    setMicState('error', 'Couldn\'t start the microphone — type your answer instead.');
  }
  // expose reset for each new question
  recognition.__reset = ()=>{ finalTranscript=''; $('#liveTranscript').value=''; };
}

function askCurrentQuestion(){
  const q = session.questions[session.index];
  $('#roomQuestionText').textContent = q;
  $('#roomProgress').textContent = `Question ${session.index+1} of ${session.questions.length}`;
  $('#liveTranscript').value = '';
  if(recognition && recognition.__reset) recognition.__reset();
  renderQList();
  speakQuestion(q);
}

function speakQuestion(text){
  const orb = $('#roomAva');
  if('speechSynthesis' in window){
    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(text);
    utter.rate = 0.98; utter.pitch = 1.02;
    utter.onstart = ()=> orb.classList.add('speaking');
    utter.onend = ()=> orb.classList.remove('speaking');
    window.speechSynthesis.speak(utter);
  }
}

$('#btnPauseResume').onclick = ()=>{
  paused = !paused;
  $('#btnPauseResume').textContent = paused ? '▶ Resume' : '⏸ Pause';
  if(paused){
    window.speechSynthesis && window.speechSynthesis.pause();
    if(recognition && recognizing){ try{ recognition.stop(); }catch(e){} }
    setMicState('', 'Paused');
  } else {
    window.speechSynthesis && window.speechSynthesis.resume();
    if(recognition && speechSupported){ try{ recognition.start(); }catch(e){} }
  }
};

$('#btnRepeat').onclick = ()=> speakQuestion(session.questions[session.index]);

$('#btnSkip').onclick = ()=>{ commitAnswer('(skipped)'); advance(); };

$('#btnSubmitAnswer').onclick = ()=>{
  const ans = $('#liveTranscript').value.trim() || '(no answer given)';
  commitAnswer(ans);
  advance();
};

function commitAnswer(text){
  session.answers.push({ question: session.questions[session.index], answer: text, tookSec: elapsedSec });
}

function advance(){
  session.index++;
  if(session.index >= session.questions.length){ finishInterview(); return; }
  askCurrentQuestion();
}

$('#btnEndEarly').onclick = ()=>{
  if(!confirm('End the interview now? Answered questions will still be scored.')) return;
  // fill remaining as skipped
  while(session.answers.length < session.questions.length){
    session.answers.push({ question: session.questions[session.answers.length], answer:'(not answered)', tookSec: elapsedSec });
  }
  finishInterview();
};

function teardownRoom(){
  clearInterval(timerHandle);
  window.speechSynthesis && window.speechSynthesis.cancel();
  if(recognition){ try{ recognition.onend=null; recognition.stop(); }catch(e){} }
  if(mediaStream){ mediaStream.getTracks().forEach(t=>t.stop()); mediaStream=null; }
}

/* ===========================================================
   SCORING ENGINE
=========================================================== */
const FILLERS = ['um','uh','like','you know','actually','basically','literally','so yeah','i mean','kind of','sort of'];

function analyzeAnswer(answer, jdSkills){
  const words = answer.trim().split(/\s+/).filter(Boolean);
  const wc = words.length;
  const lower = answer.toLowerCase();
  const fillerCount = FILLERS.reduce((sum,f)=> sum + (lower.split(f).length-1), 0);
  const fillerRate = wc ? fillerCount/wc : 0;
  const keywordHits = jdSkills.filter(k=> lower.includes(k)).length;
  const tooShort = wc < 12;
  const isSkippedOrEmpty = /^\(no answer|^\(skipped|^\(not answered/.test(answer);
  return { wc, fillerCount, fillerRate, keywordHits, tooShort, isSkippedOrEmpty };
}

function scoreSession(sess, jd, resume){
  const jdSkills = [...new Set([...extractSkillHits(jd), ...extractSkillHits(resume)])];
  const perAnswer = sess.answers.map(a=> ({...a, analysis: analyzeAnswer(a.answer, jdSkills)}));

  let commSum=0, confSum=0, relSum=0, depthSum=0, n=perAnswer.length || 1;
  const mistakes = [];

  perAnswer.forEach((a,i)=>{
    const an = a.analysis;
    if(an.isSkippedOrEmpty){
      mistakes.push({sev:'bad', text:`Question ${i+1} was skipped or left unanswered — even a rough attempt scores better than silence.`});
      return;
    }
    // Communication: penalize filler rate
    const comm = Math.max(20, 100 - an.fillerRate*600);
    commSum += comm;
    if(an.fillerCount >= 3) mistakes.push({sev:'warn', text:`Question ${i+1}: ${an.fillerCount} filler words ("um", "like", "actually"...) — try pausing silently instead of bridging with a filler.`});

    // Confidence: proxy via length + lack of hedging
    const hedges = (a.answer.match(/\b(i think|maybe|probably|i guess|not sure)\b/gi)||[]).length;
    const conf = Math.max(20, 100 - hedges*15 - (an.tooShort?20:0));
    confSum += conf;
    if(hedges>=2) mistakes.push({sev:'warn', text:`Question ${i+1}: leaned on hedging language ("I think", "maybe") — stating your answer directly reads as more confident.`});

    // Relevance: keyword overlap with JD/resume
    const rel = jdSkills.length ? Math.min(100, 40 + an.keywordHits*20) : 65;
    relSum += rel;

    // Depth: word count based, capped
    const depth = Math.min(100, Math.round((an.wc/70)*100));
    depthSum += depth;
    if(an.tooShort) mistakes.push({sev:'bad', text:`Question ${i+1}: answer was only ${an.wc} words — aim to unpack a specific example (situation, action, result).`});
  });

  const comm = Math.round(commSum/n), conf = Math.round(confSum/n), rel = Math.round(relSum/n), depth = Math.round(depthSum/n);
  const overall = Math.round(comm*0.3 + conf*0.25 + rel*0.2 + depth*0.25);

  if(mistakes.length===0){
    mistakes.push({sev:'good', text:'Clean run — no major flags. Keep answers this concrete and you\'re in strong shape.'});
  }

  return { overall, comm, conf, rel, depth, mistakes, perAnswer };
}

function finishInterview(){
  teardownRoom();
  const user = currentUser();
  const result = scoreSession(session, jdText, resumeText);
  const record = {
    id: 'iv_' + Date.now(),
    date: Date.now(),
    role: session.role,
    type: session.type,
    difficulty: session.difficulty,
    overall: result.overall,
    comm: result.comm, conf: result.conf, rel: result.rel, depth: result.depth,
    mistakes: result.mistakes,
    qa: result.perAnswer.map(a=>({question:a.question, answer:a.answer, analysis:a.analysis})),
  };
  const hist = getHistory();
  hist.push(record);
  saveHistory(hist);
  session = null;
  renderReport(record);
  document.querySelectorAll('.panel').forEach(p=>p.classList.toggle('active', p.dataset.panel==='report'));
  $$('.side-link').forEach(l=>l.classList.remove('active'));
}

/* ===========================================================
   REPORT
=========================================================== */
function verdictFor(score){
  if(score>=85) return "Excellent — you'd walk into this interview ready.";
  if(score>=70) return "Strong showing, with a few specific things to sharpen.";
  if(score>=50) return "A solid start — a couple more passes will move this a lot.";
  return "Rough draft territory — that's exactly what practice is for.";
}

function renderReport(record){
  $('#reportSubtitle').textContent = `${record.role} · ${record.type} · ${new Date(record.date).toLocaleDateString()}`;
  $('#scoreNumber').textContent = record.overall;
  $('#scoreRing').style.setProperty('--pct', record.overall);
  $('#scoreVerdict').textContent = verdictFor(record.overall);

  const setBar = (barId, valId, val)=>{ $(barId).style.width = val+'%'; $(valId).textContent = val; };
  setBar('#barComm','#valComm', record.comm);
  setBar('#barConf','#valConf', record.conf);
  setBar('#barRel','#valRel', record.rel);
  setBar('#barDepth','#valDepth', record.depth);

  $('#mistakesList').innerHTML = record.mistakes.map(m=>`
    <div class="mistake-item ${m.sev==='warn'?'warn':''}">
      <span class="mi-icon">${m.sev==='good'?'✅':m.sev==='warn'?'⚠️':'❌'}</span>
      <p>${m.text}</p>
    </div>`).join('');

  $('#qaReview').innerHTML = record.qa.map((a,i)=>{
    const flags = [];
    if(a.analysis.isSkippedOrEmpty) flags.push('<span class="flag">Skipped</span>');
    if(a.analysis.fillerCount>=3) flags.push(`<span class="flag">${a.analysis.fillerCount} filler words</span>`);
    if(a.analysis.tooShort && !a.analysis.isSkippedOrEmpty) flags.push('<span class="flag">Too short</span>');
    if(!flags.length) flags.push('<span class="flag good">Solid</span>');
    return `<div class="qa-item">
      <p class="qa-q">${i+1}. ${a.question}</p>
      <p class="qa-a">${a.answer}</p>
      <div class="qa-flags">${flags.join('')}</div>
    </div>`;
  }).join('');

  window.__lastReport = record;
}

function openReport(id){
  const hist = getHistory();
  const rec = hist.find(h=>h.id===id);
  if(!rec) return;
  renderReport(rec);
  document.querySelectorAll('.panel').forEach(p=>p.classList.toggle('active', p.dataset.panel==='report'));
  $$('.side-link').forEach(l=>l.classList.remove('active'));
}

$('#btnDownloadReport').onclick = ()=>{
  const r = window.__lastReport;
  if(!r) return;
  let out = `AIMOCK — INTERVIEW REPORT\n`;
  out += `Role: ${r.role}   Type: ${r.type}   Date: ${new Date(r.date).toLocaleString()}\n`;
  out += `Overall score: ${r.overall}/100\n\n`;
  out += `Communication: ${r.comm}   Confidence: ${r.conf}   Relevance: ${r.rel}   Depth: ${r.depth}\n\n`;
  out += `WHAT TO FIX FIRST\n`;
  r.mistakes.forEach(m=> out += `- ${m.text}\n`);
  out += `\nQUESTION BY QUESTION\n`;
  r.qa.forEach((a,i)=>{ out += `\n${i+1}. ${a.question}\nYour answer: ${a.answer}\n`; });
  const blob = new Blob([out], {type:'text/plain'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = `aimock-interview-report-${r.id}.txt`;
  a.click();
  URL.revokeObjectURL(url);
};

/* ===========================================================
   HISTORY PANEL
=========================================================== */
function renderHistory(){
  const hist = [...getHistory()].reverse();
  $('#historyEmpty').style.display = hist.length ? 'none' : 'block';
  $('#historyList').innerHTML = hist.map(h=>`
    <div class="history-row" data-id="${h.id}">
      <div class="hr-left">
        <b>${h.role} · ${h.type}</b>
        <p>${new Date(h.date).toLocaleDateString(undefined,{month:'short',day:'numeric',year:'numeric',hour:'2-digit',minute:'2-digit'})} · ${h.qa.length} questions</p>
      </div>
      <div class="hr-right">
        <span class="rr-score ${scoreClass(h.overall)}">${h.overall}</span>
      </div>
    </div>`).join('');
  $$('.history-row').forEach(r=> r.onclick = ()=> openReport(r.dataset.id));
}

/* ===========================================================
   BOOT — restore session if already signed in
=========================================================== */
if(currentUser()) enterApp();

})();
