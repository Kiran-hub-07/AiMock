# Aimock — AI Interview Studio

A front-end AI mock-interview platform: résumé + JD aware question generation,
a live camera/voice interview room, scored feedback, and a practice history —
built as three files (`index.html`, `style.css`, `app.js`).

## Run it (important — read this first)

Browsers only allow camera/microphone access (`getUserMedia`) on a **secure
context**: `https://` or `http://localhost`. Double-clicking `index.html`
opens it as `file://`, and Chrome/Edge/Firefox will silently block the
camera and mic on that origin — that's a browser security rule, not
something any page's code can override.

So run it from a local server:

```bash
cd aimock-interview
python3 -m http.server 8080
# then open http://localhost:8080
```

or open the folder in VS Code with the "Live Server" extension, or drag the
folder into Netlify Drop / Vercel / GitHub Pages for a real HTTPS URL.

Browser support for voice: Chrome, Edge, and Safari support the
`SpeechRecognition` API used for live transcription. Firefox does not — Aimock
detects this automatically and switches to a typed-answer fallback so the
interview still runs end-to-end either way. If the person denies the
mic/camera prompt, the same fallback kicks in rather than the app breaking.

## What's real vs. simulated

This is a **front-end-only build** — there's no server, so a few pieces are
intentionally simulated and clearly labeled as such in the UI:

- **"Sign in with Google / LinkedIn"** — demo buttons. A real OAuth flow
  needs a backend holding a client secret; wiring one up is a backend task
  (e.g. NextAuth, Auth0, Firebase Auth) that can sit in front of this same UI.
- **Phone OTP** — generates a real 6-digit code and displays it on-screen
  instead of texting it, since SMS delivery requires a paid gateway (Twilio,
  MSG91, etc.) called from a server. The verification logic itself
  (code matching, resend, expiry-free demo) is real.
- **"Backend"** — user accounts, uploaded résumé/JD text, question history,
  and past scores all persist in the browser's `localStorage`, scoped per
  signed-in email. Nothing is uploaded anywhere. This means data is
  per-browser, not synced across devices — swap in a real database (Postgres
  + a small API) and point `store.get/set` in `app.js` at it to make this
  multi-device.
- **Question generation** — a rules/template engine (see `ROLE_TEMPLATES`,
  `BEHAVIORAL_BANK`, and keyword extraction in `app.js`), not a live call to
  a language model. It reads keywords out of the résumé/JD text and mixes in
  role- and behavior-specific banks, tracking asked questions per user so
  repeat practice surfaces new ones. To upgrade this to true LLM-generated
  questions, replace `buildQuestionPool()` with a call to an LLM API
  (e.g. the Claude API) passing the résumé and JD text and asking for N
  tailored questions in JSON.
- **Scoring** — a transparent, explainable heuristic (filler-word rate,
  hedging language, keyword overlap with the JD, answer length) rather than
  a model judging the answer's content. It's intentionally legible — the
  report tells you exactly which signal moved which number — but it can't
  judge whether an answer's substance was actually correct. Swapping in an
  LLM-graded rubric is the natural next step if you want content-level
  feedback.

## File map

- `index.html` — all screens (landing, auth modal, dashboard, setup,
  interview room, report, history) as toggled sections.
- `style.css` — the visual system: dark "obsidian + violet + gold" palette,
  glassmorphism panels, the Ava avatar animation, scroll reveals.
- `app.js` — everything else: auth/OTP flow, résumé/JD parsing (plain text
  and PDF via pdf.js), question generation, the camera/mic interview engine,
  scoring, and history/dashboard rendering.

## Extending to a real backend later

The whole app talks to a tiny `store` object in `app.js` (`store.get` /
`store.set`, backed by `localStorage`). To move to a real backend:

1. Replace `store.get/set` calls with `fetch()` calls to your API.
2. Move OTP generation + SMS sending server-side; never expose the code to
   the client in a real deployment.
3. Add real OAuth (NextAuth/Auth0/Firebase) behind the Google/LinkedIn
   buttons.
4. Optionally route question generation and scoring through an LLM API call
   for content-aware (not just pattern-based) feedback.
